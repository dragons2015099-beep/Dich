package com.example.dichkhung

import android.content.Context
import android.net.ConnectivityManager
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Chế độ dịch: tự động / luôn online / luôn offline. */
object TranslateMode {
    const val AUTO = 0
    const val ONLINE = 1
    const val OFFLINE = 2

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("dich", Context.MODE_PRIVATE)

    fun get(ctx: Context): Int = prefs(ctx).getInt("mode", AUTO)

    fun set(ctx: Context, mode: Int) {
        prefs(ctx).edit().putInt("mode", mode).apply()
    }

    fun hasNetwork(ctx: Context): Boolean {
        val cm = ctx.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.activeNetwork != null
    }

    /** Lần dịch này có thử online trước không? */
    fun useOnline(ctx: Context): Boolean = when (get(ctx)) {
        ONLINE -> true
        OFFLINE -> false
        else -> hasNetwork(ctx)
    }
}

/**
 * Dịch online qua điểm cuối dịch miễn phí của Google (không chính thức, không cần khóa API).
 * Có thể bị giới hạn lượt dùng hoặc ngừng hoạt động bất cứ lúc nào; khi lỗi trả null.
 */
object OnlineTranslator {
    private val pool = Executors.newFixedThreadPool(4)

    private fun gcode(code: String) = if (code == "zh") "zh-CN" else code

    /** Gọi trên luồng nền. */
    fun translateBlocking(text: String, src: String): String? {
        return try {
            val q = URLEncoder.encode(text.take(500), "UTF-8")
            val url = URL(
                "https://translate.googleapis.com/translate_a/single" +
                    "?client=gtx&sl=${gcode(src)}&tl=vi&dt=t&q=$q"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val seg = arr.optJSONArray(i) ?: continue
                sb.append(seg.optString(0, ""))
            }
            sb.toString().trim().ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }

    /** Dịch song song nhiều đoạn. `done` được gọi trên luồng nền, kết quả null = đoạn đó lỗi. */
    fun translateMany(texts: List<String>, src: String, done: (List<String?>) -> Unit) {
        if (texts.isEmpty()) {
            done(emptyList())
            return
        }
        val res = arrayOfNulls<String>(texts.size)
        val left = AtomicInteger(texts.size)
        texts.forEachIndexed { i, t ->
            pool.execute {
                res[i] = translateBlocking(t, src)
                if (left.decrementAndGet() == 0) done(res.toList())
            }
        }
    }
}

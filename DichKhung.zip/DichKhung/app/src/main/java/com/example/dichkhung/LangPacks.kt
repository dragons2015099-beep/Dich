package com.example.dichkhung

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object LangPacks {
    data class Lang(val code: String, val label: String, val voiceName: String, val voiceMb: Int)

    // Dung lượng gói giọng nói lấy từ trang models của Vosk; gói dịch ML Kit khoảng 30MB mỗi ngôn ngữ
    val LANGS = listOf(
        Lang("en", "Tiếng Anh", "vosk-model-small-en-us-0.15", 40),
        Lang("zh", "Tiếng Trung", "vosk-model-small-cn-0.22", 42),
        Lang("ja", "Tiếng Nhật", "vosk-model-small-ja-0.22", 48),
        Lang("ko", "Tiếng Hàn", "vosk-model-small-ko-0.22", 82),
        Lang("fr", "Tiếng Pháp", "vosk-model-small-fr-0.22", 41),
        Lang("es", "Tiếng Tây Ban Nha", "vosk-model-small-es-0.42", 39)
    )
    val VI = Lang("vi", "Tiếng Việt", "vosk-model-small-vn-0.4", 32)
    const val TRANSLATE_MB = 30

    fun voiceName(code: String): String? = (LANGS + VI).firstOrNull { it.code == code }?.voiceName

    fun voiceDir(ctx: Context, name: String) = File(ctx.applicationContext.filesDir, "vosk/$name")

    fun voiceInstalled(ctx: Context, name: String) = File(voiceDir(ctx, name), "am/final.mdl").exists()

    fun deleteVoice(ctx: Context, name: String) {
        voiceDir(ctx, name).deleteRecursively()
    }

    /** Tải + giải nén gói giọng nói. Ném IOException nếu lỗi hoặc bị hủy. */
    fun downloadVoice(ctx: Context, name: String, cancelled: () -> Boolean, progress: (Int) -> Unit) {
        val app = ctx.applicationContext
        val zip = File(app.cacheDir, "$name.zip")
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        val total = conn.contentLengthLong
        conn.inputStream.use { inp ->
            zip.outputStream().use { out ->
                val b = ByteArray(32768)
                var done = 0L
                var last = -1
                while (true) {
                    if (cancelled()) throw IOException("đã hủy")
                    val n = inp.read(b)
                    if (n < 0) break
                    out.write(b, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last && p % 5 == 0) { last = p; progress(p) }
                    }
                }
            }
        }
        // Giải nén vào thư mục tạm rồi đổi tên, tránh mô hình dở dang
        val tmp = File(app.filesDir, "vosk_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val tmpCanon = tmp.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(tmp, e.name)
                if (!f.canonicalPath.startsWith(tmpCanon)) throw IOException("tệp zip không hợp lệ")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zin.copyTo(it) }
                }
                e = zin.nextEntry
            }
        }
        val dest = voiceDir(app, name)
        dest.parentFile?.mkdirs()
        dest.deleteRecursively()
        if (!File(tmp, name).renameTo(dest)) throw IOException("không đổi tên được thư mục mô hình")
        tmp.deleteRecursively()
        zip.delete()
    }
}

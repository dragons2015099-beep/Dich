package com.example.dichkhung

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(this).apply {
            text = "Dịch Khung"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "Bấm Bắt đầu, mở app cần dịch, kéo khung vàng lên đoạn chữ rồi bấm nút tròn Dịch. Nút 🔊 bật phụ đề dịch giọng nói (Android 13+). " +
                "Tự nhận ngôn ngữ và dịch sang tiếng Việt."
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        })
        col.addView(Button(this).apply {
            text = "Bắt đầu"
            setOnClickListener { start() }
        })
        setContentView(col)

        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO)
        else arrayOf(Manifest.permission.RECORD_AUDIO)
        requestPermissions(perms, 1)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Bật quyền \"Hiển thị trên các ứng dụng khác\" rồi quay lại bấm Bắt đầu",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, TranslateService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }
}

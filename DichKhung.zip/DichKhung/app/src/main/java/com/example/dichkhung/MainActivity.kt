package com.example.dichkhung

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel

class MainActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private val mgr by lazy { RemoteModelManager.getInstance() }
    private val packs = ArrayList<Pack>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, bold: Boolean = false, color: Int = Color.parseColor("#222222")) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    /** Một dòng gói: tên, trạng thái/dung lượng, nút Tải/Xóa. */
    private inner class Pack(
        private val title: String,
        private val mb: Int,
        private val check: ((Boolean) -> Unit) -> Unit,
        private val download: ((String) -> Unit, (String?) -> Unit) -> Unit,
        private val delete: (() -> Unit) -> Unit
    ) {
        private var installed = false
        private var busy = false
        private val status = tv("", 12f, color = Color.GRAY)
        private val btn = Button(this@MainActivity).apply {
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
        }
        val view: View = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            addView(
                LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(tv(title, 15f))
                    addView(status)
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(btn)
        }

        init {
            btn.setOnClickListener { onClick() }
            render()
        }

        fun refresh() {
            check { ok -> main.post { if (!busy) { installed = ok; render() } } }
        }

        private fun render() {
            status.text = if (installed) "Đã tải ✓" else "Chưa tải · khoảng $mb MB"
            btn.text = if (installed) "Xóa" else "Tải"
        }

        private fun onClick() {
            if (busy) return
            if (installed) {
                delete { refresh() }
                return
            }
            busy = true
            btn.isEnabled = false
            status.text = "Đang tải…"
            download(
                { p -> main.post { status.text = p } },
                { err ->
                    main.post {
                        busy = false
                        btn.isEnabled = true
                        if (err == null) {
                            installed = true
                            render()
                        } else {
                            status.text = "Lỗi: $err"
                            btn.text = "Thử lại"
                        }
                    }
                }
            )
        }
    }

    private fun translatePack(code: String, title: String): Pack {
        val model = TranslateRemoteModel.Builder(TranslateLanguage.fromLanguageTag(code) ?: code).build()
        return Pack(
            title, LangPacks.TRANSLATE_MB,
            check = { cb ->
                mgr.isModelDownloaded(model)
                    .addOnSuccessListener { cb(it) }
                    .addOnFailureListener { cb(false) }
            },
            download = { progress, done ->
                progress("Đang tải… (có thể mất vài phút)")
                mgr.download(model, DownloadConditions.Builder().build())
                    .addOnSuccessListener { done(null) }
                    .addOnFailureListener { done(it.message ?: "lỗi mạng") }
            },
            delete = { done -> mgr.deleteDownloadedModel(model).addOnCompleteListener { done() } }
        )
    }

    private fun voicePack(l: LangPacks.Lang): Pack = Pack(
        "Gói giọng nói (nghe âm thanh)", l.voiceMb,
        check = { cb -> cb(LangPacks.voiceInstalled(applicationContext, l.voiceName)) },
        download = { progress, done ->
            Thread {
                try {
                    LangPacks.downloadVoice(applicationContext, l.voiceName, { false }) { pct ->
                        progress("Đang tải $pct%")
                    }
                    done(null)
                } catch (e: Exception) {
                    LangPacks.deleteVoice(applicationContext, l.voiceName)
                    done(e.message ?: "lỗi mạng")
                }
            }.start()
        },
        delete = { done ->
            LangPacks.deleteVoice(applicationContext, l.voiceName)
            done()
        }
    )

    private fun addCard(parent: LinearLayout, heading: String, rows: List<Pack>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#DDDDDD"))
            }
        }
        card.addView(tv(heading, 17f, true))
        rows.forEach {
            packs.add(it)
            card.addView(it.view)
        }
        parent.addView(
            card,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(32))
        }
        col.addView(tv("Dịch Khung", 28f, true).apply { gravity = Gravity.CENTER })
        col.addView(
            tv(
                "Bấm Bắt đầu, mở app cần dịch, kéo khung vàng lên đoạn chữ rồi bấm nút tròn Dịch. " +
                    "Nút 🔊 dịch âm thanh trong máy, nút 🎤 dịch người đang nói qua micro (offline). Tự nhận ngôn ngữ và dịch sang tiếng Việt.",
                14f
            ).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(16)) }
        )
        col.addView(Button(this).apply {
            text = "Bắt đầu"
            setOnClickListener { start() }
        })

        col.addView(tv("Chế độ dịch", 20f, true).apply { setPadding(0, dp(28), 0, dp(4)) })
        val modes = listOf(
            "Tự động: có mạng thì dịch online, mất mạng dùng offline" to TranslateMode.AUTO,
            "Luôn dịch online (cần mạng)" to TranslateMode.ONLINE,
            "Luôn dịch offline (cần tải gói bên dưới)" to TranslateMode.OFFLINE
        )
        val rg = RadioGroup(this)
        for ((label, m) in modes) {
            rg.addView(RadioButton(this).apply {
                id = 1000 + m
                text = label
                isChecked = TranslateMode.get(this@MainActivity) == m
                setOnClickListener { TranslateMode.set(this@MainActivity, m) }
            })
        }
        col.addView(rg)
        col.addView(
            tv(
                "Dịch online dùng dịch vụ dịch miễn phí của Google (không chính thức, có thể bị giới hạn): " +
                    "chữ cần dịch sẽ được gửi lên mạng. Offline thì mọi thứ xử lý ngay trong máy.",
                13f, color = Color.GRAY
            )
        )

        col.addView(tv("Khi người nói tiếng Việt, dịch sang", 16f, true).apply { setPadding(0, dp(18), 0, dp(4)) })
        val targets = listOf(
            "Tiếng Anh" to "en", "Tiếng Trung" to "zh", "Tiếng Nhật" to "ja",
            "Tiếng Hàn" to "ko", "Tiếng Pháp" to "fr", "Tiếng Tây Ban Nha" to "es"
        )
        val rg2 = RadioGroup(this)
        targets.forEachIndexed { i, (label, c) ->
            rg2.addView(RadioButton(this).apply {
                id = 2000 + i
                text = label
                isChecked = TranslateMode.viTarget(this@MainActivity) == c
                setOnClickListener { TranslateMode.setViTarget(this@MainActivity, c) }
            })
        }
        col.addView(rg2)
        col.addView(
            tv(
                "Dùng cho nút VI ở thanh dưới khung vàng. Dịch offline cần tải gói dịch của ngôn ngữ đích ở mục bên dưới.",
                13f, color = Color.GRAY
            )
        )

        col.addView(tv("Gói ngôn ngữ cần tải", 20f, true).apply { setPadding(0, dp(28), 0, dp(4)) })
        col.addView(
            tv(
                "Nên tải trước bằng Wi-Fi. Mỗi gói dịch khoảng ${LangPacks.TRANSLATE_MB}MB, " +
                    "gói giọng nói từ 39 đến 82MB. Tải một lần rồi dùng offline. " +
                    "Cần tải gói dịch Tiếng Việt và gói dịch của ngôn ngữ bạn muốn dịch.",
                13f, color = Color.GRAY
            )
        )

        addCard(col, "Tiếng Việt", listOf(translatePack("vi", "Gói dịch (bắt buộc)"), voicePack(LangPacks.VI)))
        LangPacks.LANGS.forEach { l ->
            addCard(
                col, "${l.label} (${l.code.uppercase()})",
                listOf(translatePack(l.code, "Gói dịch sang Việt"), voicePack(l))
            )
        }

        setContentView(ScrollView(this).apply { addView(col) })

        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO)
        else arrayOf(Manifest.permission.RECORD_AUDIO)
        requestPermissions(perms, 1)
    }

    override fun onResume() {
        super.onResume()
        packs.forEach { it.refresh() }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Bật quyền \"Hiển thị trên các ứng dụng khác\" rồi quay lại bấm Bắt đầu",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val mp = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mp.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, TranslateService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }
}

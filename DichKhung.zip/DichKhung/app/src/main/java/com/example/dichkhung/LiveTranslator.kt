package com.example.dichkhung

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Thu âm thanh đang phát từ app khác (AudioPlaybackCapture, Android 10+)
 * -> nhận diện giọng nói OFFLINE bằng Vosk (không cần dịch vụ Google)
 * -> dịch sang tiếng Việt bằng ML Kit.
 * Gói giọng nói (~40-80MB) tự tải một lần cho mỗi ngôn ngữ từ alphacephei.com.
 */
class LiveTranslator(
    ctx: Context,
    private val projection: MediaProjection,
    private val onSubtitle: (original: String, vi: String?) -> Unit,
    private val onError: (String) -> Unit
) {
    companion object {
        private const val RATE = 16000
    }

    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var gen = 0
    private var worker: Thread? = null
    private val translators = HashMap<String, Translator>()

    var lang: String = "en-US"
        set(value) {
            field = value
            if (running) launch()
        }

    fun start(): Boolean {
        if (running) return true
        running = true
        launch()
        return true
    }

    fun stop() {
        if (!running) return
        running = false
        gen++
        runCatching { worker?.join(800) }
        worker = null
        main.removeCallbacksAndMessages(null)
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
    }

    private fun alive(g: Int) = running && gen == g
    private fun post(r: () -> Unit) { main.post { r() } }

    private fun launch() {
        val g = ++gen
        val prev = worker
        worker = Thread {
            runCatching { prev?.join() }
            if (alive(g)) session(g)
        }.also { it.start() }
    }

    private fun session(g: Int) {
        val code = lang.substringBefore('-')
        val name = LangPacks.voiceName(code)
        if (name == null) {
            post { onError("Chưa hỗ trợ giọng nói ngôn ngữ này") }
            return
        }
        val dir = LangPacks.voiceDir(app, name)
        if (!LangPacks.voiceInstalled(app, name)) {
            try {
                LangPacks.downloadVoice(app, name, { !alive(g) }) { pct -> post { onSubtitle("Đang tải gói giọng nói… $pct%", null) } }
            } catch (e: Exception) {
                if (alive(g)) post { onError("Không tải được gói giọng nói: ${e.message}") }
                return
            }
        }
        if (!alive(g)) return
        post { onSubtitle("Đang nạp mô hình giọng nói…", null) }

        val model = try {
            Model(dir.absolutePath)
        } catch (e: Throwable) {
            dir.deleteRecursively()
            post { onError("Không nạp được mô hình: ${e.message}") }
            return
        }
        val rc = Recognizer(model, RATE.toFloat())
        val rec = buildRecord()
        if (rec == null) {
            rc.close(); model.close()
            return
        }
        try {
            rec.startRecording()
            val buf = ByteArray(4000)
            while (alive(g)) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                if (rc.acceptWaveForm(buf, n)) {
                    val t = clean(code, JSONObject(rc.result).optString("text"))
                    if (t.isNotBlank()) post { translate(code, t) { vi -> onSubtitle(t, vi) } }
                } else {
                    val p = clean(code, JSONObject(rc.partialResult).optString("partial"))
                    if (p.isNotBlank()) post { onSubtitle(p, null) }
                }
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
            rc.close()
            model.close()
        }
    }

    // Vosk tiếng Trung/Nhật chèn dấu cách giữa các từ -> bỏ đi cho tự nhiên
    private fun clean(code: String, t: String) =
        (if (code == "zh" || code == "ja") t.replace(" ", "") else t).trim()

    @SuppressLint("MissingPermission")
    private fun buildRecord(): AudioRecord? {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        return try {
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(minBuf * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                post { onError("Không khởi tạo được thu âm thanh") }
                null
            } else r
        } catch (e: Exception) {
            post { onError("Không thu được âm thanh: ${e.message}") }
            null
        }
    }

    private fun translate(code: String, text: String, cb: (String?) -> Unit) {
        val src = TranslateLanguage.fromLanguageTag(code)
        if (src == null || src == TranslateLanguage.VIETNAMESE) { cb(null); return }
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                    .build()
            )
        }
        tr.downloadModelIfNeeded()
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { cb(it) }
                    .addOnFailureListener { cb(null) }
            }
            .addOnFailureListener { cb(null) }
    }
}

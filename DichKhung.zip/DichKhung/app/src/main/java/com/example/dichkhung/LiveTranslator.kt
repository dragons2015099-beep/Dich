package com.example.dichkhung

import android.annotation.TargetApi
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.IOException
import java.io.OutputStream

/**
 * Thu âm thanh đang phát từ app khác (AudioPlaybackCapture) -> nhận diện giọng nói
 * -> dịch sang tiếng Việt. Cần Android 13+ (EXTRA_AUDIO_SOURCE) và dịch vụ giọng nói của Google.
 */
class LiveTranslator(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val onSubtitle: (original: String, vi: String?) -> Unit,
    private val onError: (String) -> Unit
) {
    companion object { private const val RATE = 16000 }

    private val main = Handler(Looper.getMainLooper())
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var sink: OutputStream? = null
    private var readSide: ParcelFileDescriptor? = null
    private var recognizer: SpeechRecognizer? = null
    private val translators = HashMap<String, Translator>()

    var lang: String = "en-US"
        set(value) {
            field = value
            if (running) main.post { next() }
        }

    @TargetApi(33)
    fun start(): Boolean {
        if (running) return true
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError("Máy chưa có dịch vụ nhận diện giọng nói của Google")
            return false
        }
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val r = try {
            AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(minBuf * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        } catch (e: Exception) {
            onError("Không thu được âm thanh: ${e.message}")
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            onError("Không khởi tạo được thu âm thanh")
            return false
        }
        r.startRecording()
        rec = r
        running = true
        thread = Thread {
            val buf = ByteArray(3200)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) {
                    val s = sink
                    if (s != null) {
                        try { s.write(buf, 0, n) } catch (e: IOException) { sink = null }
                    }
                }
            }
        }.also { it.start() }

        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
        }
        startSession()
        return true
    }

    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacksAndMessages(null)
        endSession()
        runCatching { rec?.stop() }
        runCatching { thread?.join(300) }
        runCatching { rec?.release() }
        rec = null
        runCatching { recognizer?.cancel(); recognizer?.destroy() }
        recognizer = null
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
    }

    @TargetApi(33)
    private fun startSession() {
        if (!running) return
        endSession()
        val pipe = ParcelFileDescriptor.createPipe()
        readSide = pipe[0]
        sink = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, readSide)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, RATE)
        }
        recognizer?.startListening(i)
    }

    private fun endSession() {
        runCatching { sink?.close() }
        sink = null
        runCatching { readSide?.close() }
        readSide = null
    }

    @TargetApi(33)
    private fun next() {
        endSession()
        runCatching { recognizer?.cancel() }
        main.postDelayed({ if (running) startSession() }, 300)
    }

    private fun firstText(b: Bundle?): String? =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
            ?.takeIf { it.isNotEmpty() }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(partialResults: Bundle?) {
            firstText(partialResults)?.let { onSubtitle(it, null) }
        }

        override fun onResults(results: Bundle?) {
            firstText(results)?.let { text -> translate(text) { vi -> onSubtitle(text, vi) } }
            next()
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    onError("Thiếu quyền ghi âm"); return
                }
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                    onError("Thiết bị chưa hỗ trợ ngôn ngữ này"); return
                }
            }
            next()
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun translate(text: String, cb: (String?) -> Unit) {
        val src = TranslateLanguage.fromLanguageTag(lang.substringBefore('-'))
        if (src == null || src == TranslateLanguage.VIETNAMESE) { cb(null); return }
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                    .build()
            )
        }
        tr.downloadModelIfNeeded()
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { cb(it) }
                    .addOnFailureListener { cb(null) }
            }
            .addOnFailureListener { cb(null) }
    }
}

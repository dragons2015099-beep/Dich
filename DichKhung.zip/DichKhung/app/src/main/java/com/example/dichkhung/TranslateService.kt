package com.example.dichkhung

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Khung ngắm kiểu camera: 4 góc vàng + tâm. Không bắt chạm nên vẫn cuộn được app bên dưới. */
private class CornerView(ctx: Context, private val sw: Float) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#FFC107")
        strokeWidth = sw
        strokeCap = Paint.Cap.ROUND
    }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 255)
        strokeWidth = sw / 3f
    }

    override fun onDraw(c: Canvas) {
        val i = sw
        val w = width - i
        val h = height - i
        val l = minOf(width, height) * 0.22f
        c.drawRect(i, i, w, h, thin)
        corner(c, i, i, 1f, 1f, l)
        corner(c, w, i, -1f, 1f, l)
        corner(c, i, h, 1f, -1f, l)
        corner(c, w, h, -1f, -1f, l)
        val cx = width / 2f
        val cy = height / 2f
        c.drawLine(cx - sw * 3, cy, cx + sw * 3, cy, thin)
        c.drawLine(cx, cy - sw * 3, cx, cy + sw * 3, thin)
    }

    private fun corner(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, l: Float) {
        c.drawLine(x, y, x + dx * l, y, p)
        c.drawLine(x, y, x, y + dy * l, p)
    }
}

/** Một khối chữ đọc được: nội dung, vị trí, số dòng, ngôn ngữ (null = chữ Latin chưa biết). */
private class Cand(val text: String, val rect: Rect, val lines: Int, var lang: String?)

/** Vẽ bản dịch đè lên đúng vị trí chữ gốc, nền lấy màu từ ảnh chụp để che chữ cũ. */
private class OverlayView(ctx: Context, private val items: List<Item>) : View(ctx) {
    class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int, val srcLines: Int)

    private val dens = ctx.resources.displayMetrics.density
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val layouts = items.map { buildLayout(it) }

    private fun buildLayout(item: Item): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = item.fg
            typeface = Typeface.DEFAULT_BOLD
        }
        val w = maxOf(item.rect.width(), (40 * dens).toInt())
        val min = 9 * dens
        var size = maxOf(minOf(item.rect.height().toFloat() / item.srcLines * 0.8f, 28 * dens), min)
        var l: StaticLayout
        do {
            tp.textSize = size
            l = StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, w).build()
            size -= dens
        } while (l.height > item.rect.height() && size >= min)
        return l
    }

    override fun onDraw(c: Canvas) {
        items.forEachIndexed { i, item ->
            val l = layouts[i]
            val h = maxOf(item.rect.height(), l.height)
            bgP.color = item.bg
            val r = RectF(
                item.rect.left.toFloat(), item.rect.top.toFloat(),
                (item.rect.left + maxOf(item.rect.width(), l.width)).toFloat(),
                (item.rect.top + h).toFloat()
            )
            c.drawRoundRect(r, 4 * dens, 4 * dens, bgP)
            c.save()
            c.translate(item.rect.left.toFloat(), item.rect.top + (h - l.height) / 2f)
            l.draw(c)
            c.restore()
        }
    }
}

class TranslateService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0

    private var frameView: CornerView? = null
    private var frameLp: WindowManager.LayoutParams? = null
    private var ctrlView: LinearLayout? = null
    private var ctrlLp: WindowManager.LayoutParams? = null
    private var ctrlW = 0
    private var ctrlH = 0
    private var resultView: View? = null

    private var audioBtn: TextView? = null
    private var langBtn: TextView? = null
    private var micBtn: TextView? = null
    private var liveMic = false
    private var live: LiveTranslator? = null
    private val langs = listOf(
        "EN" to "en-US", "中" to "zh-CN", "日" to "ja-JP",
        "한" to "ko-KR", "FR" to "fr-FR", "ES" to "es-ES"
    )
    private var langIdx = 0

    private var subView: LinearLayout? = null
    private var subVi: TextView? = null
    private var subOrig: TextView? = null
    private val hideSub = Runnable { subView?.visibility = View.GONE }

    private val recognizers by lazy {
        listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mgr.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        setupCapture(mp)
        showFrame()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("dich", "Dịch màn hình", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "dich")
            .setContentTitle("Khung dịch đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        startForeground(1, n, type)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture(mp: MediaProjection) {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        sh = m.heightPixels
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = mp.createVirtualDisplay(
            "dich", sw, sh, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    // ---------- Khung ngắm + thanh nút ----------
    private fun showFrame() {
        val cv = CornerView(this, dp(4).toFloat())
        val lp = overlayParams(dp(300), dp(200), touchable = false).apply { x = dp(40); y = dp(260) }
        wm.addView(cv, lp)
        frameView = cv
        frameLp = lp
        buildControls()
        syncWindows()
    }

    private fun chip(label: String, size: Int = 40, color: String = "#CC202020"): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(color))
            }
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

    private fun buildControls() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(36).toFloat()
                setColor(Color.parseColor("#99000000"))
            }
        }
        val dragB = chip("✥")
        val sizeB = chip("⤡")
        val shutter = chip("Dịch", 54, "#FFFFFF").apply {
            setTextColor(Color.BLACK)
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            (background as GradientDrawable).setStroke(dp(3), Color.parseColor("#FFC107"))
            setOnClickListener { capture() }
        }
        val audioB = chip("🔊").apply { setOnClickListener { toggleAudio(false) } }
        val micB = chip("🎤").apply { setOnClickListener { toggleAudio(true) } }
        val langB = chip(langs[0].first).apply {
            textSize = 14f
            setOnClickListener {
                langIdx = (langIdx + 1) % langs.size
                text = langs[langIdx].first
                live?.lang = langs[langIdx].second
            }
        }
        val closeB = chip("✕").apply { setOnClickListener { stopSelf() } }
        audioBtn = audioB
        micBtn = micB
        langBtn = langB
        listOf(dragB, sizeB, shutter, audioB, micB, langB, closeB).forEach { bar.addView(it) }

        val spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        bar.measure(spec, spec)
        ctrlW = bar.measuredWidth
        ctrlH = bar.measuredHeight

        val lp = overlayParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        wm.addView(bar, lp)
        ctrlView = bar
        ctrlLp = lp

        val f = frameLp!!
        var dx = 0f; var dy = 0f
        var sx = 0; var sy = 0
        var w0 = 0; var h0 = 0
        dragB.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = f.x; sy = f.y }
                MotionEvent.ACTION_MOVE -> {
                    f.x = (sx + (e.rawX - dx).toInt()).coerceIn(0, maxOf(0, sw - f.width))
                    f.y = (sy + (e.rawY - dy).toInt()).coerceIn(0, maxOf(0, sh - f.height))
                    syncWindows()
                }
            }
            true
        }
        sizeB.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; w0 = f.width; h0 = f.height }
                MotionEvent.ACTION_MOVE -> {
                    f.width = (w0 + (e.rawX - dx).toInt()).coerceIn(dp(140), maxOf(dp(140), sw - f.x))
                    f.height = (h0 + (e.rawY - dy).toInt()).coerceIn(dp(100), maxOf(dp(100), sh - f.y))
                    syncWindows()
                }
            }
            true
        }
    }

    private fun syncWindows() {
        val f = frameLp ?: return
        val c = ctrlLp ?: return
        c.x = (f.x + (f.width - ctrlW) / 2).coerceIn(0, maxOf(0, sw - ctrlW))
        c.y = minOf(f.y + f.height + dp(10), sh - ctrlH - dp(24))
        frameView?.let { wm.updateViewLayout(it, f) }
        ctrlView?.let { wm.updateViewLayout(it, c) }
    }

    private fun setHidden(hidden: Boolean) {
        val a = if (hidden) 0f else 1f
        frameView?.alpha = a
        ctrlView?.alpha = a
        subView?.alpha = a
    }

    // ---------- Dịch chữ trong khung ----------
    private fun capture() {
        val lp = frameLp ?: return
        hideResult()
        setHidden(true)                     // ẩn khung/nút để không bị chụp vào
        main.postDelayed({ grab(lp.x, lp.y, lp.width, lp.height, 0) }, 250)
    }

    private fun grab(x: Int, y: Int, w: Int, h: Int, tries: Int) {
        val img = reader?.acquireLatestImage()
        if (img == null) {
            if (tries < 10) {
                main.postDelayed({ grab(x, y, w, h, tries + 1) }, 150)
            } else {
                setHidden(false)
                toast("Không chụp được màn hình")
            }
            return
        }
        val plane = img.planes[0]
        val bufW = plane.rowStride / plane.pixelStride
        val full = Bitmap.createBitmap(bufW, sh, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        img.close()
        setHidden(false)

        val cx = x.coerceIn(0, sw - 1)
        val cy = y.coerceIn(0, sh - 1)
        val cw = minOf(w, sw - cx).coerceAtLeast(1)
        val ch = minOf(h, sh - cy).coerceAtLeast(1)
        val crop = Bitmap.createBitmap(full, cx, cy, cw, ch)
        full.recycle()
        recognize(crop)
    }

    /** Ngôn ngữ đang chọn ở nút EN/中/日/한/FR/ES (mã 2 chữ). */
    private fun chipCode() = langs[langIdx].second.substringBefore('-')

    private fun recognize(bmp: Bitmap) {
        showResult("Đang đọc chữ…")
        val img = InputImage.fromBitmap(bmp, 0)
        // Bộ đọc Latin luôn chạy; chỉ chạy thêm bộ đọc của thứ tiếng đang chọn (中/日/한),
        // tránh bộ đọc Hàn/Nhật đọc nhầm chữ Hán thành chữ lạ rồi dịch ra rác.
        val extra = when (chipCode()) { "zh" -> 1; "ja" -> 2; "ko" -> 3; else -> -1 }
        val idx = if (extra >= 0) listOf(0, extra) else listOf(0)
        val tasks = idx.map { recognizers[it].process(img) }
        Tasks.whenAllComplete(tasks).addOnSuccessListener {
            val res = arrayOfNulls<Text>(4)
            idx.forEachIndexed { k, i ->
                val t = tasks[k]
                if (t.isSuccessful) res[i] = t.result
            }
            val cands = mergeCandidates(res.toList())
            if (cands.isEmpty()) {
                hideResult()
                toast("Không thấy chữ trong khung")
            } else {
                resolveAndTranslate(cands, bmp)
            }
        }
    }

    private fun overlap(a: Rect, b: Rect): Float {
        val i = Rect(a)
        if (!i.intersect(b)) return 0f
        val ia = i.width().toLong() * i.height()
        val m = minOf(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return if (m <= 0) 0f else ia.toFloat() / m
    }

    private fun scripts(s: String): Set<Character.UnicodeScript> {
        val set = HashSet<Character.UnicodeScript>()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            set.add(Character.UnicodeScript.of(cp))
            i += Character.charCount(cp)
        }
        return set
    }

    /** Chữ thuộc hệ chữ `ok` chiếm ít nhất 60% ký tự (bỏ khoảng trắng) và có ít nhất `min` ký tự. */
    private fun mostly(s: String, min: Int = 2, ok: (Character.UnicodeScript) -> Boolean): Boolean {
        var hit = 0
        var total = 0
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            if (Character.isWhitespace(cp)) continue
            total++
            if (ok(Character.UnicodeScript.of(cp))) hit++
        }
        return hit >= min && total > 0 && hit.toFloat() / total >= 0.6f
    }

    /** Lọc rác (ký hiệu, chữ đọc nhầm) và gộp kết quả các bộ đọc. */
    private fun mergeCandidates(res: List<Text?>): List<Cand> {
        val out = ArrayList<Cand>()
        fun addFrom(t: Text?, pick: (String) -> String?) {
            if (t == null) return
            for (b in t.textBlocks) {
                val r = b.boundingBox ?: continue
                val txt = b.text.trim()
                if (txt.isEmpty()) continue
                val lang = pick(txt) ?: continue
                if (out.any { overlap(it.rect, r) > 0.4f }) continue
                out.add(Cand(txt, Rect(r), maxOf(1, b.lines.size), if (lang == "latin") null else lang))
            }
        }
        val han = Character.UnicodeScript.HAN
        val hira = Character.UnicodeScript.HIRAGANA
        val kata = Character.UnicodeScript.KATAKANA
        val hang = Character.UnicodeScript.HANGUL
        val latn = Character.UnicodeScript.LATIN
        addFrom(res[3]) { s -> if (mostly(s) { it == hang }) "ko" else null }
        addFrom(res[2]) { s ->
            val sc = scripts(s)
            if ((hira in sc || kata in sc) && mostly(s) { it == hira || it == kata || it == han }) "ja" else null
        }
        addFrom(res[1]) { s ->
            val sc = scripts(s)
            if (han in sc && hira !in sc && kata !in sc && hang !in sc && mostly(s) { it == han }) "zh" else null
        }
        addFrom(res[0]) { s -> if (mostly(s, 1) { it == latn }) "latin" else null }
        return out
    }

    /** Khối chữ Latin: nhận ngôn ngữ riêng từng khối, khối quá ngắn thì dùng ngôn ngữ chung của cả màn hình. */
    private fun resolveAndTranslate(cands: List<Cand>, bmp: Bitmap) {
        val latin = cands.filter { it.lang == null }
        if (latin.isEmpty()) {
            translateAll(cands, bmp)
            return
        }
        showResult("Đang nhận diện ngôn ngữ…")
        val idc = LanguageIdentification.getClient()
        val chip = chipCode()
        val fallback = if (chip == "en" || chip == "fr" || chip == "es") chip else "vi"
        val next: (String) -> Unit = { globalLang ->
            val idTasks = latin.map { c -> idc.identifyLanguage(c.text) }
            Tasks.whenAllComplete(idTasks).addOnSuccessListener {
                for (i in latin.indices) {
                    val l = if (idTasks[i].isSuccessful) idTasks[i].result else "und"
                    latin[i].lang = if (l == "und") globalLang else l
                }
                translateAll(cands, bmp)
            }
        }
        idc.identifyLanguage(latin.joinToString(". ") { it.text })
            .addOnSuccessListener { g -> next(if (g == "und") fallback else g) }
            .addOnFailureListener { next(fallback) }
    }

    private fun translateAll(cands: List<Cand>, bmp: Bitmap) {
        val groups = cands
            .filter { c -> c.lang != null && c.lang != "vi" && TranslateLanguage.fromLanguageTag(c.lang!!) != null }
            .groupBy { c -> c.lang!! }
        if (groups.isEmpty()) {
            hideResult()
            toast("Không có chữ nước ngoài cần dịch. Muốn dịch chữ Trung/Nhật/Hàn, bấm nút ngôn ngữ để chọn 中/日/한")
            return
        }
        showResult(
            if (TranslateMode.useOnline(this)) "Đang dịch online…"
            else "Đang dịch offline…\n\nLần đầu cần tải gói dịch (khoảng 30MB mỗi ngôn ngữ). Có thể tải trước ở màn hình chính của app, mục Gói ngôn ngữ."
        )
        val items = ArrayList<OverlayView.Item>()
        val errors = ArrayList<String>()
        var anyOnline = false
        var pending = groups.size
        fun done() {
            pending--
            if (pending > 0) return
            if (items.isNotEmpty()) {
                showOverlay(items, anyOnline)
            } else if (errors.isNotEmpty()) {
                showResult("Không dịch được: ${errors.first()}\n\nNếu đang offline, mở app Dịch Khung, mục Gói ngôn ngữ, để tải trước gói dịch.")
            } else {
                showResult("Không có chữ nào cần dịch trong khung")
            }
        }
        for ((code, list) in groups) {
            val joiner = if (code == "zh" || code == "ja") "" else " "
            val srcTexts = list.map { c -> c.text.replace("\n", joiner) }
            translateGroup(code, srcTexts) { outs, online, err ->
                if (online) anyOnline = true
                if (err != null) errors.add(err)
                for (i in list.indices) {
                    val out = outs[i] ?: continue
                    if (out.equals(srcTexts[i], ignoreCase = true)) continue   // số, tên riêng giữ nguyên
                    items.add(makeItem(list[i], out, bmp))
                }
                done()
            }
        }
    }

    /** Dịch một nhóm cùng ngôn ngữ: online trước nếu được, lỗi thì (chế độ Tự động) rơi về offline. */
    private fun translateGroup(code: String, texts: List<String>, cb: (List<String?>, Boolean, String?) -> Unit) {
        if (!TranslateMode.useOnline(this)) {
            offlineTranslate(code, texts) { outs, err -> cb(outs, false, err) }
            return
        }
        OnlineTranslator.translateMany(texts, code) { outs ->
            main.post {
                val failed = outs.indices.filter { outs[it] == null }
                if (failed.isEmpty()) {
                    cb(outs, true, null)
                } else if (TranslateMode.get(this) != TranslateMode.AUTO) {
                    cb(outs, true, "không kết nối được máy chủ dịch online")
                } else {
                    offlineTranslate(code, failed.map { texts[it] }) { offOuts, err ->
                        val merged = outs.toMutableList()
                        failed.forEachIndexed { k, idx -> merged[idx] = offOuts[k] }
                        cb(merged, failed.size < texts.size, err)
                    }
                }
            }
        }
    }

    private fun offlineTranslate(code: String, texts: List<String>, cb: (List<String?>, String?) -> Unit) {
        val src = TranslateLanguage.fromLanguageTag(code)
        if (src == null) {
            cb(texts.map { null }, "ngôn ngữ chưa được hỗ trợ")
            return
        }
        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build()
        )
        tr.downloadModelIfNeeded()
            .addOnSuccessListener {
                val jobs = texts.map { t -> tr.translate(t) }
                Tasks.whenAllComplete(jobs).addOnSuccessListener {
                    tr.close()
                    cb(jobs.map { j -> if (j.isSuccessful) j.result else null }, null)
                }
            }
            .addOnFailureListener { e ->
                tr.close()
                cb(texts.map { null }, e.message ?: "không tải được gói dịch offline")
            }
    }

    private fun makeItem(c: Cand, vi: String, bmp: Bitmap): OverlayView.Item {
        val r = Rect(c.rect)
        r.inset(-dp(2), -dp(1))
        r.intersect(0, 0, bmp.width, bmp.height)
        val bg = edgeColor(bmp, r)
        val lum = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000
        val fg = if (lum > 140) Color.BLACK else Color.WHITE
        return OverlayView.Item(r, vi, bg, fg, c.lines)
    }

    /** Màu nền trung bình ngay bên ngoài khung chữ (tránh lấy màu của nét chữ). */
    private fun edgeColor(bmp: Bitmap, r: Rect): Int {
        val o = Rect(r)
        o.inset(-dp(3), -dp(3))
        var rs = 0; var gs = 0; var bs = 0; var n = 0
        fun add(x: Int, y: Int) {
            val p = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            rs += Color.red(p); gs += Color.green(p); bs += Color.blue(p); n++
        }
        for (i in 0..6) {
            val x = o.left + o.width() * i / 6
            val y = o.top + o.height() * i / 6
            add(x, o.top); add(x, o.bottom)
            add(o.left, y); add(o.right, y)
        }
        return Color.rgb(rs / n, gs / n, bs / n)
    }

    private fun showOverlay(items: List<OverlayView.Item>, online: Boolean) {
        hideResult()
        val f = frameLp ?: return
        val v = OverlayView(this, items).apply { setOnClickListener { hideResult() } }
        val lp = overlayParams(f.width, f.height).apply { x = f.x; y = f.y }
        wm.addView(v, lp)
        resultView = v
        toast((if (online) "Dịch online" else "Dịch offline") + " · chạm vào khung để đóng")
    }

    private fun showResult(text: String) {
        hideResult()
        val f = frameLp ?: return
        val tv = TextView(this).apply {
            this.text = text + "\n\n(chạm để đóng)"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { hideResult() }
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EE102030"))
            addView(tv)
        }
        val lp = overlayParams(f.width, maxOf(f.height, dp(160))).apply { x = f.x; y = f.y }
        wm.addView(sv, lp)
        resultView = sv
    }

    private fun hideResult() {
        resultView?.let { runCatching { wm.removeView(it) } }
        resultView = null
    }

    // ---------- Dịch âm thanh -> phụ đề ----------
    private fun toggleAudio(mic: Boolean) {
        if (live != null) {
            val wasMic = liveMic
            stopLive()
            if (wasMic == mic) return          // bấm lại đúng nút đang bật = tắt
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Chưa có quyền ghi âm: vào Cài đặt > Ứng dụng > Dịch Khung > Quyền")
            return
        }
        val mp = projection ?: return
        val lt = LiveTranslator(this, mp, ::onSubtitle, ::onLiveError, mic)
        lt.lang = langs[langIdx].second
        if (lt.start()) {
            live = lt
            liveMic = mic
            setAudioState(if (mic) 2 else 1)
            toast(
                (if (mic) "Đang nghe người nói qua micro" else "Đang nghe âm thanh trong máy") +
                    " (${langs[langIdx].first})"
            )
        }
    }

    private fun stopLive() {
        live?.stop()
        live = null
        liveMic = false
        setAudioState(0)
        main.removeCallbacks(hideSub)
        subView?.visibility = View.GONE
    }

    private fun onLiveError(msg: String) {
        toast(msg)
        stopLive()
    }

    /** 0 = tắt, 1 = đang nghe âm thanh trong máy (🔊), 2 = đang nghe micro (🎤) */
    private fun setAudioState(mode: Int) {
        (audioBtn?.background as? GradientDrawable)
            ?.setColor(Color.parseColor(if (mode == 1) "#E53935" else "#CC202020"))
        (micBtn?.background as? GradientDrawable)
            ?.setColor(Color.parseColor(if (mode == 2) "#E53935" else "#CC202020"))
    }

    private fun ensureSubtitle() {
        if (subView != null) return
        val vi = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val orig = TextView(this).apply {
            setTextColor(Color.parseColor("#BBBBBB"))
            textSize = 13f
            gravity = Gravity.CENTER
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.parseColor("#B0000000"))
            addView(vi)
            addView(orig)
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(110)
        }
        wm.addView(box, lp)
        subView = box
        subVi = vi
        subOrig = orig
    }

    private fun onSubtitle(original: String, vi: String?) {
        if (live == null) return
        ensureSubtitle()
        subVi?.text = vi ?: original
        subOrig?.text = if (vi == null) "" else original
        subView?.visibility = View.VISIBLE
        main.removeCallbacks(hideSub)
        main.postDelayed(hideSub, 7000)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        stopLive()
        hideResult()
        listOf<View?>(frameView, ctrlView, subView).forEach { v ->
            v?.let { runCatching { wm.removeView(it) } }
        }
        frameView = null; ctrlView = null; subView = null
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizers.forEach { it.close() }
        super.onDestroy()
    }
}

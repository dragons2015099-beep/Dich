package com.example.dichkhung

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Khung ngắm kiểu camera: 4 góc vàng + tâm. Không bắt chạm nên vẫn cuộn được app bên dưới. */
private class CornerView(ctx: Context, private val sw: Float) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#FFC107")
        strokeWidth = sw
        strokeCap = Paint.Cap.ROUND
    }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 255)
        strokeWidth = sw / 3f
    }

    override fun onDraw(c: Canvas) {
        val i = sw
        val w = width - i
        val h = height - i
        val l = minOf(width, height) * 0.22f
        c.drawRect(i, i, w, h, thin)
        corner(c, i, i, 1f, 1f, l)
        corner(c, w, i, -1f, 1f, l)
        corner(c, i, h, 1f, -1f, l)
        corner(c, w, h, -1f, -1f, l)
        val cx = width / 2f
        val cy = height / 2f
        c.drawLine(cx - sw * 3, cy, cx + sw * 3, cy, thin)
        c.drawLine(cx, cy - sw * 3, cx, cy + sw * 3, thin)
    }

    private fun corner(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, l: Float) {
        c.drawLine(x, y, x + dx * l, y, p)
        c.drawLine(x, y, x, y + dy * l, p)
    }
}

class TranslateService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0

    private var frameView: CornerView? = null
    private var frameLp: WindowManager.LayoutParams? = null
    private var ctrlView: LinearLayout? = null
    private var ctrlLp: WindowManager.LayoutParams? = null
    private var ctrlW = 0
    private var ctrlH = 0
    private var resultView: View? = null

    private var audioBtn: TextView? = null
    private var langBtn: TextView? = null
    private var live: LiveTranslator? = null
    private val langs = listOf(
        "EN" to "en-US", "中" to "zh-CN", "日" to "ja-JP",
        "한" to "ko-KR", "FR" to "fr-FR", "ES" to "es-ES"
    )
    private var langIdx = 0

    private var subView: LinearLayout? = null
    private var subVi: TextView? = null
    private var subOrig: TextView? = null
    private val hideSub = Runnable { subView?.visibility = View.GONE }

    private val recognizers by lazy {
        listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mgr.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        setupCapture(mp)
        showFrame()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("dich", "Dịch màn hình", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "dich")
            .setContentTitle("Khung dịch đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun setupCapture(mp: MediaProjection) {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        sh = m.heightPixels
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = mp.createVirtualDisplay(
            "dich", sw, sh, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int, touchable: Boolean = true): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    // ---------- Khung ngắm + thanh nút ----------
    private fun showFrame() {
        val cv = CornerView(this, dp(4).toFloat())
        val lp = overlayParams(dp(300), dp(200), touchable = false).apply { x = dp(40); y = dp(260) }
        wm.addView(cv, lp)
        frameView = cv
        frameLp = lp
        buildControls()
        syncWindows()
    }

    private fun chip(label: String, size: Int = 44, color: String = "#CC202020"): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(color))
            }
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
        }

    private fun buildControls() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(36).toFloat()
                setColor(Color.parseColor("#99000000"))
            }
        }
        val dragB = chip("✥")
        val sizeB = chip("⤡")
        val shutter = chip("Dịch", 58, "#FFFFFF").apply {
            setTextColor(Color.BLACK)
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            (background as GradientDrawable).setStroke(dp(3), Color.parseColor("#FFC107"))
            setOnClickListener { capture() }
        }
        val audioB = chip("🔊").apply { setOnClickListener { toggleAudio() } }
        val langB = chip(langs[0].first).apply {
            textSize = 14f
            setOnClickListener {
                langIdx = (langIdx + 1) % langs.size
                text = langs[langIdx].first
                live?.lang = langs[langIdx].second
            }
        }
        val closeB = chip("✕").apply { setOnClickListener { stopSelf() } }
        audioBtn = audioB
        langBtn = langB
        listOf(dragB, sizeB, shutter, audioB, langB, closeB).forEach { bar.addView(it) }

        val spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        bar.measure(spec, spec)
        ctrlW = bar.measuredWidth
        ctrlH = bar.measuredHeight

        val lp = overlayParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        wm.addView(bar, lp)
        ctrlView = bar
        ctrlLp = lp

        val f = frameLp!!
        var dx = 0f; var dy = 0f
        var sx = 0; var sy = 0
        var w0 = 0; var h0 = 0
        dragB.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = f.x; sy = f.y }
                MotionEvent.ACTION_MOVE -> {
                    f.x = (sx + (e.rawX - dx).toInt()).coerceIn(0, maxOf(0, sw - f.width))
                    f.y = (sy + (e.rawY - dy).toInt()).coerceIn(0, maxOf(0, sh - f.height))
                    syncWindows()
                }
            }
            true
        }
        sizeB.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; w0 = f.width; h0 = f.height }
                MotionEvent.ACTION_MOVE -> {
                    f.width = (w0 + (e.rawX - dx).toInt()).coerceIn(dp(140), maxOf(dp(140), sw - f.x))
                    f.height = (h0 + (e.rawY - dy).toInt()).coerceIn(dp(100), maxOf(dp(100), sh - f.y))
                    syncWindows()
                }
            }
            true
        }
    }

    private fun syncWindows() {
        val f = frameLp ?: return
        val c = ctrlLp ?: return
        c.x = (f.x + (f.width - ctrlW) / 2).coerceIn(0, maxOf(0, sw - ctrlW))
        c.y = minOf(f.y + f.height + dp(10), sh - ctrlH - dp(24))
        frameView?.let { wm.updateViewLayout(it, f) }
        ctrlView?.let { wm.updateViewLayout(it, c) }
    }

    private fun setHidden(hidden: Boolean) {
        val a = if (hidden) 0f else 1f
        frameView?.alpha = a
        ctrlView?.alpha = a
        subView?.alpha = a
    }

    // ---------- Dịch chữ trong khung ----------
    private fun capture() {
        val lp = frameLp ?: return
        hideResult()
        setHidden(true)                     // ẩn khung/nút để không bị chụp vào
        main.postDelayed({ grab(lp.x, lp.y, lp.width, lp.height, 0) }, 250)
    }

    private fun grab(x: Int, y: Int, w: Int, h: Int, tries: Int) {
        val img = reader?.acquireLatestImage()
        if (img == null) {
            if (tries < 10) {
                main.postDelayed({ grab(x, y, w, h, tries + 1) }, 150)
            } else {
                setHidden(false)
                toast("Không chụp được màn hình")
            }
            return
        }
        val plane = img.planes[0]
        val bufW = plane.rowStride / plane.pixelStride
        val full = Bitmap.createBitmap(bufW, sh, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        img.close()
        setHidden(false)

        val cx = x.coerceIn(0, sw - 1)
        val cy = y.coerceIn(0, sh - 1)
        val cw = minOf(w, sw - cx).coerceAtLeast(1)
        val ch = minOf(h, sh - cy).coerceAtLeast(1)
        val crop = Bitmap.createBitmap(full, cx, cy, cw, ch)
        full.recycle()
        recognize(crop)
    }

    private fun recognize(bmp: Bitmap) {
        showResult("Đang đọc chữ…")
        val img = InputImage.fromBitmap(bmp, 0)
        val tasks = recognizers.map { it.process(img) }
        Tasks.whenAllComplete(tasks).addOnSuccessListener {
            val texts = tasks.map { t -> if (t.isSuccessful) t.result.text.trim() else "" }
            val best = texts.maxByOrNull { it.length } ?: ""
            if (best.isBlank()) {
                hideResult()
                toast("Không thấy chữ trong khung")
            } else {
                translate(best)
            }
        }
    }

    private fun translate(text: String) {
        LanguageIdentification.getClient().identifyLanguage(text)
            .addOnSuccessListener { code ->
                val src = TranslateLanguage.fromLanguageTag(code)
                if (code == "und" || src == null) {
                    showResult("Không nhận ra ngôn ngữ:\n\n$text")
                    return@addOnSuccessListener
                }
                if (src == TranslateLanguage.VIETNAMESE) {
                    showResult(text)
                    return@addOnSuccessListener
                }
                showResult("Đang dịch… (lần đầu cần mạng để tải gói ngôn ngữ)")
                val tr = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                        .build()
                )
                tr.downloadModelIfNeeded()
                    .addOnSuccessListener {
                        tr.translate(text)
                            .addOnSuccessListener { out -> showResult(out); tr.close() }
                            .addOnFailureListener { showResult("Lỗi dịch"); tr.close() }
                    }
                    .addOnFailureListener {
                        showResult("Không tải được gói ngôn ngữ, kiểm tra mạng")
                        tr.close()
                    }
            }
            .addOnFailureListener { showResult("Lỗi nhận diện ngôn ngữ") }
    }

    private fun showResult(text: String) {
        hideResult()
        val f = frameLp ?: return
        val tv = TextView(this).apply {
            this.text = text + "\n\n(chạm để đóng)"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { hideResult() }
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EE102030"))
            addView(tv)
        }
        val lp = overlayParams(f.width, maxOf(f.height, dp(160))).apply { x = f.x; y = f.y }
        wm.addView(sv, lp)
        resultView = sv
    }

    private fun hideResult() {
        resultView?.let { runCatching { wm.removeView(it) } }
        resultView = null
    }

    // ---------- Dịch âm thanh -> phụ đề ----------
    private fun toggleAudio() {
        if (live != null) {
            stopLive()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Chưa có quyền ghi âm: vào Cài đặt > Ứng dụng > Dịch Khung > Quyền")
            return
        }
        val mp = projection ?: return
        val lt = LiveTranslator(this, mp, ::onSubtitle, ::onLiveError)
        lt.lang = langs[langIdx].second
        if (lt.start()) {
            live = lt
            setAudioOn(true)
            toast("Đang nghe âm thanh trong máy (${langs[langIdx].first})")
        }
    }

    private fun stopLive() {
        live?.stop()
        live = null
        setAudioOn(false)
        main.removeCallbacks(hideSub)
        subView?.visibility = View.GONE
    }

    private fun onLiveError(msg: String) {
        toast(msg)
        stopLive()
    }

    private fun setAudioOn(on: Boolean) {
        (audioBtn?.background as? GradientDrawable)
            ?.setColor(Color.parseColor(if (on) "#E53935" else "#CC202020"))
    }

    private fun ensureSubtitle() {
        if (subView != null) return
        val vi = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val orig = TextView(this).apply {
            setTextColor(Color.parseColor("#BBBBBB"))
            textSize = 13f
            gravity = Gravity.CENTER
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.parseColor("#B0000000"))
            addView(vi)
            addView(orig)
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(110)
        }
        wm.addView(box, lp)
        subView = box
        subVi = vi
        subOrig = orig
    }

    private fun onSubtitle(original: String, vi: String?) {
        if (live == null) return
        ensureSubtitle()
        subVi?.text = vi ?: original
        subOrig?.text = if (vi == null) "" else original
        subView?.visibility = View.VISIBLE
        main.removeCallbacks(hideSub)
        main.postDelayed(hideSub, 7000)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        stopLive()
        hideResult()
        listOf<View?>(frameView, ctrlView, subView).forEach { v ->
            v?.let { runCatching { wm.removeView(it) } }
        }
        frameView = null; ctrlView = null; subView = null
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizers.forEach { it.close() }
        super.onDestroy()
    }
}

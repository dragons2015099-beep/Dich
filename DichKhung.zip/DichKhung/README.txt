DICH KHUNG - Android (Kotlin)
1. Cai Android Studio ban moi nhat.
2. File > Open > chon thu muc DichKhung, doi Gradle sync xong.
3. Cam dien thoai (bat gdebug USB), bam Run.
4. Mo app > cap quyen Micro (can cho dich am thanh) > Bat dau > cap quyen hien tren app khac + ghi man hinh.
5. Khung ngam vang noi tren moi app. Hang nut: ✥ keo | ⤡ doi kich thuoc | Dich (chup + dich chu)
   | 🔊 bat/tat dich giong noi | EN/中/日/한/FR/ES chon ngon ngu giong noi | ✕ tat.
Dich chu: lan dau moi cap ngon ngu can mang de tai goi, sau do offline.
Dich am thanh: can Android 13+, dich vu giong noi Google (can mang), app nguon khong chan thu am thanh.

DICH KHUNG - Android (Kotlin)
Build: Android Studio (Build > Build APK) hoac day len GitHub, tab Actions se build ra app-debug.apk.
Dung: cap quyen Micro > Bat dau > cap hien tren app khac + ghi man hinh (chon "Toan man hinh").
Khung ngam vang noi tren moi app. Hang nut: keo | doi kich thuoc | Dich (chup + dich chu)
 | loa bat/tat dich giong noi | EN/中/日/한/FR/ES chon ngon ngu giong noi | X tat.
Dich chu: lan dau moi cap ngon ngu can mang de tai goi, sau do offline.
Dich giong noi: nhan dien offline bang Vosk (Android 10+), khong can Google.
 Lan dau moi ngon ngu tu tai goi giong noi 40-82MB tu alphacephei.com. Dich sang Viet van dung ML Kit.
 App nguon chan thu am thanh (Netflix, ngan hang...) se khong thu duoc.
